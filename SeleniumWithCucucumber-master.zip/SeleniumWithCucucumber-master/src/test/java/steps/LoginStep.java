package steps;

import Base.BaseUtil;
import com.aventstack.extentreports.GherkinKeyword;

import io.cucumber.java.DataTableType;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.github.bonigarcia.wdm.WebDriverManager;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

import pages.LoginPage;

import java.util.List;
import java.util.Map;



public class LoginStep  {

    //private  BaseUtil base;
	 public static WebDriver Driver;
	
	 
    public LoginStep() {
        
    }

    

@Test
    @Then("^validate store information$")
    public void storeInformation() throws Throwable {
       // scenarioDef.createNode(new GherkinKeyword("Then"), "I should see the userform page");
	 boolean strtxt=Driver.findElement(By.xpath("//*[@id='block_contact_infos']/div/ul/li[1]/i")).isDisplayed();
     org.testng.Assert.assertTrue(strtxt);
     System.out.println(strtxt);
    }
@Test
    @Given("^I navigate to the login page$")
    public void iNavigateToTheLoginPage() throws Throwable {
       // base.scenarioDef.createNode(new GherkinKeyword("Given"), "I navigate to the login page");
	  System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir")+"//drivers//chromedriver.exe");

      //Initializing the browser driver
	  WebDriverManager.chromedriver().setup();
       Driver = new ChromeDriver();    
	System.out.println("Navigate Login Page");
        Driver.get("http://automationpractice.com/index.php");
        Thread.sleep(3000);
        Driver.manage().window().maximize();
       
    }

@Test
    @And("^remove from the cart$")
    public void removeFromTheCart() throws Throwable {
        //scenarioDef.createNode(new GherkinKeyword("And"), "I click login button");
	 LoginPage page = new LoginPage(Driver);    
	page.removeFromTheCarts();
    }
@Test
@And("^Delete from the cart$")
public void deleteFromCart() throws Throwable {
    //scenarioDef.createNode(new GherkinKeyword("And"), "I click login button");
 LoginPage page = new LoginPage(Driver);    
page.delete();
}

@Test
@And("^search and validate items$")
public void search() throws Throwable {
    //scenarioDef.createNode(new GherkinKeyword("And"), "I click login button");
 LoginPage page = new LoginPage(Driver);    
page.searchitems();

String strtext=Driver.findElement(By.xpath("//*[@id='center_column']/p")).getText();
org.testng.Assert.assertEquals(strtext, "No results were found for your search \"toys\"");
}
@Test
    @And("^add items in cart$")
    public void iTemsInCart() throws Throwable {
	//page.items.click();
	 LoginPage page = new LoginPage(Driver);
	
	// page.items.click();
	 page.items.click();
		Thread.sleep(15000);
		WebElement el=Driver.findElement(By.xpath("//iframe[@class='fancybox-iframe']"));
		
		Driver.switchTo().frame(el);
    page.addingIntoCart(); 

    }


  
   


   

}
