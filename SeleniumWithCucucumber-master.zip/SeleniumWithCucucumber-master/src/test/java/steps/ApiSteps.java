package steps;

import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

import cucumber.api.java.en.And;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.TimeUnit;
import org.testng.annotations.Test;
import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.cucumber.java.en.Given;



public class ApiSteps {
	@Test
    @Given("^I fetch the api data$")
    public void fetchApiData() throws Throwable {
     
		String url="https://www.breakingbadapi.com/api/characters?name=Walter White";
		
		Response response = RestAssured.get(url);
		// store the response body in string
		String responseBody = response.getBody().asString();
		// print the response
		System.out.println("Response Body is =>  " + responseBody);
		JsonPath jsonPathEvaluator = response.jsonPath();
		System.out.println("Get Birthday =>  " + jsonPathEvaluator.get("birthday"));
		// store the response code
		int responseStatusCode = response.getStatusCode();
		System.out.println("************************************************");
		System.out.println("Status Code => "+ responseStatusCode);
		System.out.println(response.getTimeIn(TimeUnit.MILLISECONDS));
    }
	
	@Test
    @And("^Get all characters information$")
    public void allcharacters() throws Throwable {
     
		String url="https://www.breakingbadapi.com/api/characters";
		
		Response response = RestAssured.get(url);
		// store the response body in string
		String responseBody = response.getBody().asString();
		// print the response
		System.out.println("Response Body is =>  " + responseBody);
		System.out.println("Response length =>  " + responseBody.length());
		List<String> lis = new ArrayList<>();
		for(int i=1;i<=responseBody.length();i++) {
			 response = RestAssured.get("https://www.breakingbadapi.com/api/characters/"+i);
			// store the response body in string
			 responseBody = response.getBody().asString();
			// print the response
			System.out.println("Response Body is =>  " + responseBody);
			
			lis.addAll(Arrays.asList(responseBody));
			
			
		}
		System.out.println("list of data set=>"+lis);
		// store the response code
		int responseStatusCode = response.getStatusCode();
		System.out.println("************************************************");
		System.out.println("Status Code => "+ responseStatusCode);
		System.out.println(response.getTimeIn(TimeUnit.MILLISECONDS));
	}
}
