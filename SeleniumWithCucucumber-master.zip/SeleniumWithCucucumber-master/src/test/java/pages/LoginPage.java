package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import io.reactivex.rxjava3.functions.Action;
import net.masterthought.cucumber.generators.AbstractPage;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

/**
 *
 */
public class LoginPage    {
	
	
	
	  public LoginPage(WebDriver driver) { 
		  PageFactory.initElements(driver, this);
		  
	  }
	

	
	 @FindBy(xpath="//*[@id=\"homefeatured\"]/li[1]/div/div[1]/div/a[1]")
	 public WebElement items;
	@FindBy(xpath = "//p[@id='add_to_cart']/button")
	public WebElement addCart;
	@FindBy(xpath = "//span[@title='Close window']")
	public WebElement closeWindow;
	@FindBy(xpath = "//*[@id=\"header\"]/div[3]/div/div/div[3]/div/a")
	public WebElement removecart;
	@FindBy(xpath = "//a[@title='Delete']")
	public WebElement deleteCart;
	@FindBy(xpath = "//input[@id='search_query_top']")
	public WebElement search;
	@FindBy(xpath = "//button[@name='submit_search']")
	public WebElement search_submit;
	@FindBy(xpath = "//*[@id='block_contact_infos']/div/ul/li[1]/i")
	public WebElement store_info;
	
	
	public void addingIntoCart() throws Exception {
		
		
		addCart.click();
		Thread.sleep(7000);
		closeWindow.click();
	}
	public void removeFromTheCarts() throws InterruptedException {
		Thread.sleep(5000);
		removecart.click();
		Thread.sleep(5000);
	}
	public void delete() throws Exception {
		
		deleteCart.click();
		Thread.sleep(5000);
	}
	public void searchitems() throws Exception {
		search.click();
		search.clear();
		search.sendKeys("shirts");
		search_submit.click();
		Thread.sleep(5000);
		search.click();
		search.clear();
		search.sendKeys("toys");
		search_submit.click();
		
		
		
	}




	

}
